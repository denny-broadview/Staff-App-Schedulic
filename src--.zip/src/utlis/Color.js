export default {
  AppColor:'#424DE4',
  white: "#FFFFFF",
  ligthGray:"#A3A3A3",
  darkGray:'#484848',
  silver:'#A8A8A8',
  gray:'#9C9C9C',
  bleck:'#000000',
  richBlue:'#5059ae',
  darkPink:'#b44666',
  green:'#45B124',
  ontheway:'#0EC619',
  workstarted:'#007BFF',
  aqeva:'#00B9FF',
  ligthGreen:'#169A23',
  iconAccount:'#868686',
  pink:'#FF0088',
  yellow:'#FFA000',
  blue:'#272E96',
  ligthGreen:'#0ECCC5',
  line:'#E2E2E2'
  
};