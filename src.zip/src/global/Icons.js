
// Check out at 'http://ionicframework.com/docs/v2/ionicons/' for more icons
// 'react-native-vector-icons/Ionicons'

const Ionicons = {
  Browse:"ios-browsers",
  
  
};

// https://materialdesignicons.com/
// 'react-native-vector-icons/MaterialCommunityIcons'
const MaterialCommunityIcons = {
  Menu: "menu",
  
};

export default { MaterialCommunityIcons, Ionicons };
