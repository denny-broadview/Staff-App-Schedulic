export default {
     'PTSansCaption': "PTSans-Caption",
     'PTSansCaptionBold' :  "PTSans-CaptionBold"
}